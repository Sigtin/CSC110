package game;

public class Driver {

	public static void main(String[] args) {
		App.run();

	}

}
