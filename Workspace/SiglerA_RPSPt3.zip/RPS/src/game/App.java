package game;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Random;

import enums.RPS;
import lib.ConsoleIO;

public class App {
	public static BufferedReader readRacer = new BufferedReader(new InputStreamReader(System.in));

	public static Player welcome() {
		Player p1 = new Player();
		p1.playerName();
		System.out.println("Welcome, " + p1.getPlayerName() + ", to Rock, Paper, Scissors");
		return p1;
	}

	public static int prompt() {
		String[] rps = new String[3];
		rps[0] = RPS.ROCK.toString();
		rps[1] = RPS.PAPER.toString();
		rps[2] = RPS.SCISSORS.toString();

		int input = ConsoleIO.promptForMenuSelection(rps, true);
		return input;
	}

	public static RPS CPUGuess() {
		Random rand = new Random();
		int i = rand.nextInt(3);
		RPS guess = RPS.values()[i];
		return guess;
	}

	public static boolean isLooping = true;
	public static void playerGuess(int input, RPS guess, Player p1) {
		switch (input) {

		case 1:
			System.out.println("Player: " + RPS.ROCK);
			System.out.println("CPU: " + guess);
			if (guess == RPS.PAPER) {
				System.out.println(p1.getPlayerName() + " loses!");
				System.out.println("CPU wins!");
			} else if (guess == RPS.SCISSORS) {
				System.out.println(p1.getPlayerName() + " wins!");
				System.out.println("CPU loses!");
			} else {
				System.out.println(p1.getPlayerName() + " ties with CPU!");
			}
			break;

		case 2:
			System.out.println("Player: " + RPS.PAPER);
			System.out.println("CPU: " + guess);
			if (guess == RPS.SCISSORS) {
				System.out.println(p1.getPlayerName() + " loses!");
				System.out.println("CPU wins!");
			} else if (guess == RPS.ROCK) {
				System.out.println(p1.getPlayerName() + " wins!");
				System.out.println("CPU loses!");
			} else {
				System.out.println(p1.getPlayerName() + " ties with CPU!");
			}
			break;

		case 3:
			System.out.println("Player: " + RPS.SCISSORS);
			System.out.println("CPU: " + guess);
			if (guess == RPS.ROCK) {
				System.out.println(p1.getPlayerName() + " loses!");
				System.out.println("CPU wins!");
			} else if (guess == RPS.PAPER) {
				System.out.println(p1.getPlayerName() + " wins!");
				System.out.println("CPU loses!");
			} else {
				System.out.println(p1.getPlayerName() + " ties with CPU!");
			}
			break;

		default:
			System.out.println("Thank you, " + p1.getPlayerName() + ", for playing Rock, Paper, Scissors");
			isLooping = false;
			break;

		}

	}

	
	public static void run() {
		Player p = welcome();
		do {
			int i = prompt();
			RPS g = CPUGuess();
			playerGuess(i, g, p);
		} while (isLooping);
	}

}
