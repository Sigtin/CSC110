package deckDemoEnums;

public enum DeckDemoCardSuits {
	CLUBS,
	HEARTS,
	DIAMONDS,
	SPADES
}
