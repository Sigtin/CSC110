package deckDemoApp;

public class DeckDemoDriver {

	public static void main(String[] args) {
		DeckDemoRun.run();

	}

}
