package app;

public class ZombieDiceDriver {

	public static void main(String[] args) {
		ZombieDiceRun.run();

	}

}
