package enums;

public enum ZombieDiceDieFace {
	BLAST,
	ESCAPE,
	BRAIN
}
