package enums;

public enum ZombieDiceDieType {
	RED,
	YELLOW,
	GREEN
}
