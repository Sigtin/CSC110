package rollingDice;

public class Driver {

	public static void main(String[] args) {
		Application.run();

	}

}
