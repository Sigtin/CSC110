package exercises;

import java.io.IOException;

public class Driver {

	//Manually declare the main method
	//Pop quiz: What is the alternate term for main?
		//ENTRY POINT
	public static void main(String[] args) throws IOException{
		DataTypeAnalyzer.run();
	}
}
