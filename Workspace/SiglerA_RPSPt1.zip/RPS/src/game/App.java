package game;

import java.util.Random;

import enums.RPS;
import lib.ConsoleIO;

public class App {
	public static void run() {
		boolean isValid = true;
		do {
			Random rand = new Random();
			int i = rand.nextInt(3);
			RPS guess = RPS.values()[i];
			System.out.println(guess);
			if(!ConsoleIO.promptForInput("", true).equals("")){
				isValid = false;
			}
		} while (isValid);

	}

}
