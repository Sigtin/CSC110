package math;

public class Simple {

	public static void main(String[] args) {
		int x = 20;
		int y = 35;
		System.out.println(x + "+" + y + "=" + (x + y));
		
		System.out.println(x + "-" + y + "=" + (x - y));
		
		System.out.println(x + "*" + y + "=" + (x * y));
		
		System.out.println(x + "/" + y + "=" + (x / y));
		
		System.out.println(x + "%" + y + "=" + (x % y));

	}

}
